def two_sum (array, target)
 result = true 
  arr = []
  array.each {|i| arr << array.sample(2).uniq }
  arr.each_with_index{|val, index| puts index, val.inject(:+) if val == target}
end

two_sum([1,2,3,4,5,6], 8)

# approach: check to see if you can iterate 2 by 2 reading from left to right and reverse to get the sum.
# approach: take the target and use it to see if any numbers in the array equal the value

#BUG cant get output to sum values in each array. If statement is not evaluating correctly. 

# Two-Sum

# Define a method, #two_sum, that accepts an array and a target sum (integer) as arguments.
# The method should return true if any two integers in the array sum to the target.
# Otherwise, it should return false. Assume the array will only contain integers.

def two_sum(array, target)
  # your code here
end

puts "------Two Sum------"
puts two_sum([1,2,3,4,5,6], 8) == true
puts two_sum([1,2,3,4,5,6], 18) == false
puts two_sum([1,3,6], 6) == false
puts two_sum([1,8,2,1], 0) == false